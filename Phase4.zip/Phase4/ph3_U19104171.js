<script>

var modal = document.getElementById('signin');

window.onclick = function(event)
{
    if (event.target == form)
    {
        modal.style.display = "none";
    }
}


</script>