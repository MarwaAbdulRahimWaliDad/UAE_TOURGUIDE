<script>
document.getElementById("demo").innerHTML =
"AbuDhabi: " + document.title;

function myFunction() {
  document.open("text/html","replace");
  document.write("<h3>Hotels</h3>");
  document.close();
}

function myFunction() {
  document.open("text/html","replace");
  document.write("<h4>Atractions</h4>");
  document.close();

	const img = document.querySelectorAll("img"); 



</script>